jpr <- function(eps, htt, h0m, h0V, h_mu, h_rho, h_sig, theta, tau2, z, T, c) {
  .Call('_JPR_jpr', PACKAGE = 'JPR', eps, htt, h0m, h0V, h_mu, h_rho, h_sig, theta, tau2, z, T, c)
}